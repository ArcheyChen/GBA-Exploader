#ifdef __cplusplus
extern "C" {
#endif

extern bool LoadSkin(int mod, char *Name);

#ifdef __cplusplus
}
#endif
