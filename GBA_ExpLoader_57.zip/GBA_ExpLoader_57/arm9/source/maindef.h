
#ifndef maindef_h
#define maindef_h

#define ROMTITLE "GBA ExpLoader"
#define ROMVERSION "Version 0.57 by Rudolph."
#define ROMDATE ""__DATE__" "__TIME__

#endif

