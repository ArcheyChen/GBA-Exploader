
extern	char	*errmsg[];
extern	char	*cnfmsg[];
extern	char	*barmsg[];
extern	char	*cmd_m[];
extern	char	*t_msg[];
extern	char	*savmsg[];


#ifdef __cplusplus
extern "C" {
#endif

extern	void	setLangMsg(void);

extern	char *jstrncpy(char *s1, char *s2, size_t n);

#ifdef __cplusplus
}
#endif
