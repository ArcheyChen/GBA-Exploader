#ifdef __cplusplus
extern "C" {
#endif

extern	void	header_rep(u8 *rwbuf);

#ifdef __cplusplus
}
#endif
